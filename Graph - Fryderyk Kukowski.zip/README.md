# Python Project - Graphs
Projekt na zaliczenie przedmiotu "Język programowania Python".

Implementuje on jedną klasę `Graph`, która może robić różne przydatne rzeczy z grafami.

Najważniejszy plik to `Graph.py`.

Aby sprawdzić działanie klasy należy uruchomić testy (pliki zaczynające się od `test`) i ewentualnie pozmieniać im parametry.

